package zb.grms;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.KeyValueTextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

public class GoodsStep6 extends Configured implements Tool {
    public static void main(String[] args) {
        try {
            ToolRunner.run(new GoodsStep6(), args);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    /*
    第二步
    205	5:1.0,4:0.05
    商品  用户:偏好值
    第五步
    205	204:1,205:1,318:1,319:1,431:1,730:1,203:1,88:1,89:1
    商品  商品:共现次数
    输出数据
    用户:商品   推荐值
     */
    public static class GS6Mapper extends Mapper<Text,Text,Text,Text> {
        @Override
        protected void map(Text key, Text value, Context context) throws IOException, InterruptedException {
            String[] split = value.toString().split(",");
            for(String str:split) {
                //key=商品    value=[用户:偏好值,商品:共现次数,...]
                context.write(key,new Text(str));
            }
        }
    }
    public static class GS6Reducer extends Reducer<Text,Text,Text, DoubleWritable> {
        @Override
        protected void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
            //偏好集合
            Map<String,String> like = new HashMap<>();
            //共现集合
            Map<String,String> same = new HashMap<>();
            for(Text value:values) {
                String data = value.toString();
                String[] split = data.split(":");
                //根据类型进行判断
                if(split[1].contains(".")) {
                    like.put(split[0],split[1]);
                }else {
                    same.put(split[0],split[1]);
                }
            }
            //进行乘积运算
            for(Map.Entry<String,String> l:like.entrySet()) {
                for(Map.Entry<String,String> s:same.entrySet()) {
                    //用户偏好值
                    BigDecimal lvalue = new BigDecimal(l.getValue());
                    //物品共现
                    BigDecimal svalue = new BigDecimal(s.getValue());
                    //用户:共现商品
                    Text outkey = new Text(l.getKey() + ":" + s.getKey());
                    double outvalue = lvalue.multiply(svalue).doubleValue();
                    context.write(outkey, new DoubleWritable(outvalue));
                }
            }
        }
    }
    @Override
    public int run(String[] strings) throws Exception {
        Configuration conf = getConf();
        Job job = Job.getInstance(conf, "step6");
        job.setJarByClass(this.getClass());
        //自定义mapper
        job.setMapperClass(GS6Mapper.class);
        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(Text.class);
        //默认reduce
        job.setReducerClass(GS6Reducer.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(Text.class);
        //输入分片类型
        job.setInputFormatClass(KeyValueTextInputFormat.class);
        KeyValueTextInputFormat.setInputPaths(job, new Path("src/main/resources/step2"),
                new Path("src/main/resources/step5"));
        job.setOutputFormatClass(TextOutputFormat.class);
        TextOutputFormat.setOutputPath(job,new Path("src/main/resources/step6"));
        job.waitForCompletion(true);
        return 0;
    }
}
