package zb.grms;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.KeyValueTextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

import java.io.IOException;
import java.util.ArrayList;

public class GoodsStep3 extends Configured implements Tool {
    public static void main(String[] args) {
        try {
            ToolRunner.run(new GoodsStep3(), args);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    /*
    4:150	0.2
    4:203	0.25
    4:204	1.05
    输入数据
    用户:商品   偏好
    输出数据
    用户 <商品，商品，商品>
     */
    public static class GS3Mapper extends Mapper<Text, Text,Text,Text> {
        @Override
        protected void map(Text key, Text value, Context context) throws IOException, InterruptedException {
            String uid_gid = key.toString();
            String[] split = uid_gid.split(":");
            //将用户id作为输出的key
            Text outkey = new Text(split[0]);
            //将商品id作为输出的value
            Text outvalue = new Text(split[1]);
            context.write(outkey, outvalue);
        }
    }
    /*
    输入数据
    用户 <商品，商品，商品>
    输出数据
    商品  商品
     */
    public static class GS3Reducer extends Reducer<Text,Text,Text,Text> {
        @Override
        protected void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
            /*
            进行商品俩俩组合，对商品列表进行遍历，组合商品共现关系，由于value列表是单向的，不能进行俩俩组合
            需要将所有商品放入新容器，通过容器进行组合
             */
            ArrayList<String> list = new ArrayList<>();
            for(Text value:values) {
                list.add(value.toString());
            }
            for(String g1:list) {
                for(String g2:list) {
                    if(!g1.equals(g2)) {
                        Text outkey = new Text(g1);
                        Text outvalue = new Text(g2);
                        context.write(outkey, outvalue);
                    }
                }
            }
        }
    }
    @Override
    public int run(String[] strings) throws Exception {
        Configuration conf = getConf();
        Job job = Job.getInstance(conf, "step3");
        job.setJarByClass(this.getClass());
        //自定义mapper
        job.setMapperClass(GS3Mapper.class);
        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(Text.class);
        //默认reduce
        job.setReducerClass(GS3Reducer.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(Text.class);
        //输入分片类型
        job.setInputFormatClass(KeyValueTextInputFormat.class);
        KeyValueTextInputFormat.addInputPath(job, new Path("src/main/resources/step1"));
        job.setOutputFormatClass(TextOutputFormat.class);
        TextOutputFormat.setOutputPath(job,new Path("src/main/resources/step3"));
        job.waitForCompletion(true);
        return 0;
    }
}
