package zb.grms;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.KeyValueTextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

import java.io.IOException;

public class GoodsStep5 extends Configured implements Tool {
    public static void main(String[] args) {
        try {
            ToolRunner.run(new GoodsStep5(),  args);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    /*
    150:203	1
    150:204	1
    150:205	1
    150:318	1
    输入数据
    商品:商品   次数
    输出数据
    商品  商品:1,商品:1....
     */
    public static class GS5Mapper extends Mapper<Text,Text,Text,Text> {
        @Override
        protected void map(Text key, Text value, Context context) throws IOException, InterruptedException {
            String goods = key.toString();
            String[] split = goods.split(":");
            //key=第一列商品 value=第二列商品:次数
            Text outkey = new Text(split[0]);
            Text outvalue = new Text(split[1] + ":" + value.toString());
            context.write(outkey, outvalue);
        }
    }
    public static class GS5Reducer extends Reducer<Text,Text,Text,Text> {
        @Override
        protected void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
            StringBuffer sb = new StringBuffer();
            for(Text value:values) {
                sb.append(value).append(",");
            }
            sb.setLength(sb.length()-1);
            Text outvalue = new Text(sb.toString());
            context.write(key, outvalue);
        }
    }
    @Override
    public int run(String[] strings) throws Exception {
        Configuration conf = getConf();
        Job job = Job.getInstance(conf, "step5");
        job.setJarByClass(this.getClass());
        //自定义mapper
        job.setMapperClass(GS5Mapper.class);
        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(Text.class);
        //默认reduce
        job.setReducerClass(GS5Reducer.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(Text.class);
        //输入分片类型
        job.setInputFormatClass(KeyValueTextInputFormat.class);
        KeyValueTextInputFormat.addInputPath(job, new Path("src/main/resources/step4"));
        job.setOutputFormatClass(TextOutputFormat.class);
        TextOutputFormat.setOutputPath(job,new Path("src/main/resources/step5"));
        job.waitForCompletion(true);
        return 0;
    }
}
