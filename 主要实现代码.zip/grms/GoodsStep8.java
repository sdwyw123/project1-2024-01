package zb.grms;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

import java.io.IOException;

public class GoodsStep8 extends Configured implements Tool {
    public static void main(String[] args) {
        try {
            ToolRunner.run(new GoodsStep8(), args);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    /*
    4,88,addReview,2024 一月 09 12:59:29,192
    4,89,view,2024 一月 09 13:29:15,708
    4,89,addCar,2024 一月 09 13:29:31,631
    输入数据
    用户，商品，行为，时间
    输出数据
    用户:商品   支付成功(次数)
     */
    public static class GS8Mapper extends Mapper<LongWritable, Text,Text, IntWritable> {
        @Override
        protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
            String[] split = value.toString().split(",");
            if(split.length>=3) {
                String data = split[2].toLowerCase();
                if(data.equals("paysuccess")) {
                    Text outkey = new Text(split[0] + ":" + split[1]);
                    IntWritable outvalue = new IntWritable(1);
                    context.write(outkey, outvalue);
                }
            }
        }
    }
    public static class GS8Reducer extends Reducer<Text, IntWritable,Text,IntWritable> {
        @Override
        protected void reduce(Text key, Iterable<IntWritable> values, Context context) throws IOException, InterruptedException {
            int num = 0;
            for(IntWritable i:values) {
                num++;
            }
            if(num==1)
            context.write(key, new IntWritable(num));
        }
    }
    @Override
    public int run(String[] strings) throws Exception {
        Configuration conf = getConf();
        Job job = Job.getInstance(conf, "step8");
        job.setJarByClass(this.getClass());
        //自定义mapper
        job.setMapperClass(GS8Mapper.class);
        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(IntWritable.class);
        //默认reduce
        job.setReducerClass(GS8Reducer.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(IntWritable.class);
        //输入分片类型
        job.setInputFormatClass(TextInputFormat.class);
        TextInputFormat.addInputPath(job, new Path("data/userLog.log"));
        job.setOutputFormatClass(TextOutputFormat.class);
        TextOutputFormat.setOutputPath(job,new Path("src/main/resources/step8"));
        job.waitForCompletion(true);
        return 0;
    }
}
