package zb.grms;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.KeyValueTextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.mapreduce.lib.reduce.IntSumReducer;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

import java.io.IOException;

public class GoodsStep2 extends Configured implements Tool {
    public static void main(String[] args) {
        try {
            ToolRunner.run(new GoodsStep2(), args);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    /*
    4:150	0.2
    4:203	0.25
    4:204	1.05
    4:205	0.05
    用户:商品   偏好值
    输出数据
    商品  用户:偏好值,用户:偏好值...
     */
    public static class GS2Mapper extends Mapper<Text,Text,Text,Text> {
        @Override
        protected void map(Text key, Text value, Context context) throws IOException, InterruptedException {
            String uid_gid = key.toString();
            String[] split = uid_gid.split(":");
            //将商品id作为输出key
            Text outkey = new Text(split[1]);
            //将用户id与偏好值组合形成value
            Text outvalue = new Text(split[0] + ":" + value.toString());
            context.write(outkey, outvalue);
        }
    }
    public static class GS2Reducer extends Reducer<Text,Text,Text,Text> {
        @Override
        protected void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
            StringBuffer buffer = new StringBuffer();
            for(Text value:values) {
                buffer.append(value.toString()).append(",");
            }
            //去除最后一个逗号
            buffer.setLength(buffer.length()-1);
            Text outvalue = new Text(buffer.toString());
            context.write(key, outvalue);
        }
    }
    @Override
    public int run(String[] strings) throws Exception {
        Configuration conf = getConf();
        Job job = Job.getInstance(conf, "step2");
        job.setJarByClass(this.getClass());
        //自定义mapper
        job.setMapperClass(GS2Mapper.class);
        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(Text.class);
        //默认reduce
        job.setReducerClass(GS2Reducer.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(Text.class);
        //输入分片类型
        job.setInputFormatClass(KeyValueTextInputFormat.class);
        KeyValueTextInputFormat.addInputPath(job, new Path("src/main/resources/step1"));
        job.setOutputFormatClass(TextOutputFormat.class);
        TextOutputFormat.setOutputPath(job,new Path("src/main/resources/step2"));
        job.waitForCompletion(true);
        return 0;
    }
}
