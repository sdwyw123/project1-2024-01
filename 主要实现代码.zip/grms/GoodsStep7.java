package zb.grms;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.KeyValueTextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

import java.io.IOException;
import java.math.BigDecimal;

public class GoodsStep7 extends Configured implements Tool {
    public static void main(String[] args) {
        try {
            ToolRunner.run(new GoodsStep7(), args);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    /*
    4:88	0.2
    4:89	0.2
    4:431	0.2
    输入数据
    用户:商品   推荐值
    输出数据
    用户:商品   总推荐值
     */
    public static class GS7Mapper extends Mapper<Text,Text,Text,Text> {
        @Override
        protected void map(Text key, Text value, Context context) throws IOException, InterruptedException {
            context.write(key, value);
        }
    }
    public static class GS7Reducer extends Reducer<Text,Text,Text, DoubleWritable> {
        @Override
        protected void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
            //避免精度丢失选用bigDecimal
            BigDecimal sum = new BigDecimal(0.0);
            for(Text value:values) {
                BigDecimal v = new BigDecimal(value.toString());
                sum = sum.add(v);
            }
            DoubleWritable outvalue = new DoubleWritable(sum.doubleValue());
            context.write(key, outvalue);
        }
    }
    @Override
    public int run(String[] strings) throws Exception {
        Configuration conf = getConf();
        Job job = Job.getInstance(conf, "step7");
        job.setJarByClass(this.getClass());
        //自定义mapper
        job.setMapperClass(GS7Mapper.class);
        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(Text.class);
        //默认reduce
        job.setReducerClass(GS7Reducer.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(DoubleWritable.class);
        //输入分片类型
        job.setInputFormatClass(KeyValueTextInputFormat.class);
        KeyValueTextInputFormat.addInputPath(job, new Path("src/main/resources/step6"));
        job.setOutputFormatClass(TextOutputFormat.class);
        TextOutputFormat.setOutputPath(job,new Path("src/main/resources/step7"));
        job.waitForCompletion(true);
        return 0;
    }
}
