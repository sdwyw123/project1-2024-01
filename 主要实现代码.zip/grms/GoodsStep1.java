package zb.grms;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.KeyValueTextInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

import java.io.IOException;
import java.math.BigDecimal;

public class GoodsStep1 extends Configured implements Tool {
    public static void main(String[] args) {
        try {
            ToolRunner.run(new GoodsStep1(), args);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    /*
    4,88,addReview,2024 一月 09 12:59:29,192
    4,89,view,2024 一月 09 13:29:15,708
    4,89,addCar,2024 一月 09 13:29:31,631
     */
    public static class GS1Mapper extends Mapper<LongWritable, Text,Text, DoubleWritable> {
        @Override
        protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
            String[] split = value.toString().split(",");
            //将行为转换成偏好值
            double like = 0.0;
            //清洗
            if(split.length>=3) {
                String str = split[2].toLowerCase();
                if(str.equals("paysuccess")) {
                    like = 0.3;
                }else if(str.equals("addreview")) {
                    like = 0.3;
                }else if(str.equals("createorder")) {
                    like = 0.2;
                }else if(str.equals("addcar")) {
                    like = 0.15;
                }else {
                    like = 0.05;
                }
            }
            //key=用户:商品  value=[偏好,偏好....]
            Text outkey = new Text(split[0] + ":" + split[1]);
            DoubleWritable outvalue = new DoubleWritable(like);
            context.write(outkey, outvalue);

        }
    }
    public static class GS1Reducer extends Reducer<Text, DoubleWritable,Text, DoubleWritable> {
        @Override
        protected void reduce(Text key, Iterable<DoubleWritable> values, Context context) throws IOException, InterruptedException {
            //避免精度丢失选用bigDecimal
            BigDecimal sum = new BigDecimal(0.0);
            for(DoubleWritable value:values) {
                BigDecimal v = new BigDecimal(value.get());
                sum = sum.add(v);
            }
            DoubleWritable outvalue = new DoubleWritable(sum.doubleValue());
            context.write(key, outvalue);
        }
    }
    @Override
    public int run(String[] strings) throws Exception {
        Configuration conf = getConf();
        Job job = Job.getInstance(conf, "step1");
        job.setJarByClass(this.getClass());
        //自定义mapper
        job.setMapperClass(GS1Mapper.class);
        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(DoubleWritable.class);
        //默认reduce
        job.setReducerClass(GS1Reducer.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(DoubleWritable.class);
        //输入分片类型
        job.setInputFormatClass(TextInputFormat.class);
        TextInputFormat.addInputPath(job, new Path("data/userLog.log"));
        job.setOutputFormatClass(TextOutputFormat.class);
        TextOutputFormat.setOutputPath(job,new Path("src/main/resources/step1"));
        job.waitForCompletion(true);
        return 0;
    }
}
