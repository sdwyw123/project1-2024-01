package zb.grms;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.KeyValueTextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

import java.io.IOException;
import java.util.Iterator;

public class GoodsStep8_2 extends Configured implements Tool {
    public static void main(String[] args) {
        try {
            ToolRunner.run(new GoodsStep8_2(), args);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    /*
    4:150	5.25
    4:203	5.2
    4:204	4.4
    第七步输入数据
    用户:商品   推荐值
    4:204	1
    4:730	1
    5:205	1
    第八步输入数据
    用户:商品   购买次数
    输出数据
    用户:商品   推荐值(清洗)
     */
    public static class GS8_2Mapper extends Mapper<Text,Text,Text,Text> {
        @Override
        protected void map(Text key, Text value, Context context) throws IOException, InterruptedException {
            context.write(key,value);
        }
    }
    public static class GS8_2Reducer extends Reducer<Text,Text,Text,Text> {
        //如果values列表中有两个数据(推荐值，支付次数)清洗
        @Override
        protected void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
            Iterator<Text> iter = values.iterator();
            Text outvalue = iter.next();
            if(iter.hasNext()) {}
            else {
                context.write(key, outvalue);
            }
        }
    }
    @Override
    public int run(String[] strings) throws Exception {
        Configuration conf = getConf();
        Job job = Job.getInstance(conf, "step8_2");
        job.setJarByClass(this.getClass());
        //自定义mapper
        job.setMapperClass(GS8_2Mapper.class);
        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(Text.class);
        //默认reduce
        job.setReducerClass(GS8_2Reducer.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(Text.class);
        //输入分片类型
        job.setInputFormatClass(KeyValueTextInputFormat.class);
        KeyValueTextInputFormat.setInputPaths(job, new Path("src/main/resources/step7"),
                new Path("src/main/resources/step8"));
        job.setOutputFormatClass(TextOutputFormat.class);
        TextOutputFormat.setOutputPath(job,new Path("src/main/resources/step8_2"));
        job.waitForCompletion(true);
        return 0;
    }
}
