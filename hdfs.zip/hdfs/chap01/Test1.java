package zb.hdfs.chap01;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;

import java.io.IOException;

public class Test1 {
    public static void main(String[] args) {
        //1.获取配置信息对象
        Configuration configuration = new Configuration();
        configuration.set("fs.defaultFS", "hdfs://192.168.222.132:9000");
        try {
            //2.获取hdfs文件系统
            FileSystem fs = FileSystem.get(configuration);
            //3.使用文件系统获取hdfs上的某个文件对应的流
            Path path = new Path("/data/ihad.txt");
            FSDataInputStream open = fs.open(path);
//            System.out.println(open.available());
            //使用流进行操作
            byte[] bytes = new byte[1024];
            int num = 0;
            while ((num = open.read(bytes)) != -1) {
                System.out.print(new String(bytes));
            }
            //关闭资源
            open.close();
            fs.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
