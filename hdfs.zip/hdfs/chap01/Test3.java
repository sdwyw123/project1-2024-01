package zb.hdfs.chap01;


import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataOutputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;

import java.io.FileInputStream;
import java.io.IOException;

public class Test3 {
    public static void main(String[] args) {
        Configuration configuration = new Configuration();
        configuration.set("fs.defaultFS", "hdfs://192.168.222.132:9000");
        Path path = new Path("/data/course.txt");
        try {
            FileSystem fs = FileSystem.get(configuration);
            FSDataOutputStream fos = fs.create(path);//创建
            //读取本地文件
            FileInputStream fis = new FileInputStream("data/course.txt");
            int count = 0;
            byte[] b = new byte[1024];
            while ((count = fis.read(b)) != -1) {
                fos.write(b);
            }
            fos.flush();
            fos.close();
            fis.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
