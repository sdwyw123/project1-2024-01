package zb.hdfs.chap01;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hdfs.client.HdfsDataInputStream;
import org.apache.hadoop.hdfs.protocol.ExtendedBlock;
import org.apache.hadoop.hdfs.protocol.LocatedBlock;

import java.io.IOException;
import java.util.List;

public class Test4 {
    public static void main(String[] args) {
        Configuration configuration = new Configuration();
        configuration.set("fs.defaultFS", "hdfs://192.168.222.132:9000");
        try {
            FileSystem fs = FileSystem.get(configuration);
            Path path = new Path("/data/ihad.txt");
            //保存path对应的文件的块信息
            FSDataInputStream open = fs.open(path);
            HdfsDataInputStream dis = (HdfsDataInputStream) open;
            List<LocatedBlock> allBlocks = dis.getAllBlocks();
            for (LocatedBlock b : allBlocks) {
                ExtendedBlock block = b.getBlock();
                System.out.println("id:" + block.getBlockId());
                System.out.println("name:" + block.getBlockName());
                System.out.println("size:" + block.getNumBytes());
            }
            //获取文件的元信息
            FileStatus[] status = fs.listStatus(path);
            for (FileStatus f : status) {
                System.out.println(f.isDirectory());
                System.out.println(f.getPath());
                System.out.println(f.getAccessTime());
                System.out.println(f.getOwner());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
