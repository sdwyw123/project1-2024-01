package zb.hdfs.chap01;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;

import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;


/**
 * ClassName : Test2
 * Package : zb.hdfs
 * Description :使用hadoop的打包方式执行，给代码传参数
 * hadoop jar *.jar zb.hdfs.Test2 -D inpath=/data/ihad.txt
 */
public class Test2 extends Configured implements Tool {

    public static void main(String[] args) {
        try {
            ToolRunner.run(new Test2(), args);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public int run(String[] strings) throws Exception {
        // 获取配置对象
        Configuration conf = getConf();

        FileSystem fs = FileSystem.get(conf);
        String inpath = conf.get("inpath");
        Path path = new Path(inpath);

        FSDataInputStream open = fs.open(path);
        byte[] bytes = new byte[1024];
        int num = 0;
        while ((num = open.read(bytes)) != -1) {
            System.out.println(new String(bytes));
        }
        //关闭资源
        open.close();
        fs.close();
        return 0;
    }
}
