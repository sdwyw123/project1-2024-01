package zb.hdfs.chap02;

import com.fasterxml.jackson.databind.SequenceWriter;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.SequenceFile;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

public class SequenceTest2 extends Configured implements Tool {
    public static void main(String[] args) {
        try {
            ToolRunner.run(new SequenceTest2(), args);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public int run(String[] strings) throws Exception {
        Configuration conf = getConf();
        //获取输出路径
        Path path = new Path(conf.get("inpath"));
        SequenceFile.Reader.Option file = SequenceFile.Reader.file(path);
        SequenceFile.Reader reader = new SequenceFile.Reader(conf, file);

        Writable key = (Writable) reader.getKeyClass().newInstance();
        Writable value = (Writable) reader.getValueClass().newInstance();
        while (reader.next(key, value)) {
            //获取同步标记
            boolean flag = reader.syncSeen();
            if (flag) System.out.println("**************");
            System.out.println(key + "-" + value);
        }
        return 0;
    }
}
