package zb.hdfs.chap02;

import org.apache.hadoop.io.IntWritable;

import java.io.*;
import java.util.Arrays;

public class JavaTest {
    public static void main(String[] args) {
        //java序列化
        int a = 10;
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try {
            ObjectOutputStream oos = new ObjectOutputStream(bos);
            //序列化操作
            oos.writeObject(a);
            oos.flush();
            //转换字节数组
            byte[] bytes = bos.toByteArray();
            System.out.println(Arrays.toString(bytes));
            //hadoop序列化
            //将int包装成intwritable
            IntWritable iw = new IntWritable(a);
            ByteArrayOutputStream bos2 = new ByteArrayOutputStream();
            DataOutputStream dos = new DataOutputStream(bos2);
            iw.write(dos);
            dos.flush();
            byte[] bytes2 = bos2.toByteArray();
            System.out.println(Arrays.toString(bytes2));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
