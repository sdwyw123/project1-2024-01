package zb.hdfs.chap02;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.SequenceFile;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

public class SequenceTest extends Configured implements Tool {
    public static void main(String[] args) {
        try {
            ToolRunner.run(new SequenceTest(), args);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public int run(String[] strings) throws Exception {
        Configuration conf = getConf();
        //获取输出路径
        Path path = new Path(conf.get("outpath"));
        SequenceFile.Writer.Option file = SequenceFile.Writer.file(path);
        SequenceFile.Writer.Option key = SequenceFile.Writer.keyClass(IntWritable.class);
        SequenceFile.Writer.Option value = SequenceFile.Writer.valueClass(Text.class);

        //获取序列化文件对象
        SequenceFile.Writer writer = SequenceFile.createWriter(conf, file, key, value);
        for (int i = 0; i <= 100; i++) {
            //每5个数据写一个同步标记
            if (i % 5 == 0) writer.sync();
            writer.append(new IntWritable(i), new Text("briup-" + i));
        }
        return 0;
    }
}
